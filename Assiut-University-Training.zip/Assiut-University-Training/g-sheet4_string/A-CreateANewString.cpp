#include <iostream>
#include <algorithm>
#include <string>
using namespace std;

int main()
{
    string first, second;
    cin >> first >> second;
    cout << first.size() << " " << second.size() << endl;
    cout << first << " " << second << endl;
}