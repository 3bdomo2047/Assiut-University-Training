while (cases--)
    // {
    //     int num;
    //     cin >> num;

    //     int start = 0;
    //     int mid = size / 2;
    //     int end = size - 1;

    //     while (true)
    //     {
    //         if (num == arr[start] || num == arr[end] || num == arr[mid])
    //         {
    //             cout << "found" << endl;
    //             break;
    //         }
    //         else if (mid == start + 1 && mid == end - 1)
    //         {
    //             cout << "not found" << endl;
    //             break;
    //         }
    //         else if (num > mid)
    //         {

    //             start = mid;
    //             mid = (end + start) / 2;
    //         }
    //         else if (num < mid)
    //         {

    //             end = mid;
    //             mid = (end + start) / 2;
    //         }
    //     }
    // }