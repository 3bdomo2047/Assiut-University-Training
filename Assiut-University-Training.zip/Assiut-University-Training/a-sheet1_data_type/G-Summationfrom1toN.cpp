#include <iostream>
#include <iomanip>
using namespace std;
#define lol long long int
#define endl '\n'

int main()
{
    long long num;
    cin >> num;
    cout << num * (num + 1) / 2 << endl;
}