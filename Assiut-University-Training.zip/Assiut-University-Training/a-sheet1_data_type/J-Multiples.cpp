#include <iostream>
#include <iomanip>
#include <cmath>
using namespace std;
#define lol long long int
#define endl '\n'

int main()
{
    int num1, num2;
    cin >> num1 >> num2;
    if (num1 >= num2)
    {
        cout << "Yes" << endl;
    }
    else
    {
        cout << "No" << endl;
    }
}