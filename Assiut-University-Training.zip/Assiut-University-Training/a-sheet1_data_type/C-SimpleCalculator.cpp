#include <iostream>
using namespace std;
#define lol long long int
#define endl '\n'

int main()
{
    long long num1, num2;
    cin >> num1 >> num2;
    cout << num1 << " + " << num2 << " = " << num1 + num2 << endl;
    cout << num1 << " * " << num2 << " = " << num1 * num2 << endl;
    cout << num1 << " - " << num2 << " = " << num1 - num2 << endl;
}