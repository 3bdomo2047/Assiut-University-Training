#include <iostream>
using namespace std;
#define lol long long int
#define endl '\n'

int main()
{

    string name;
    cin >> name;

    cout << "Hello, " << name;
}