#include <iostream>
using namespace std;
#define lol long long int
#define endl '\n'

int main()
{
    int num1;
    long long num2;
    char c;
    float num3;
    double num4;
    cin >> num1 >> num2 >> c >> num3 >> num4;
    cout << num1 << endl;
    cout << num2 << endl;
    cout << c << endl;
    cout << num3 << endl;
    cout << num4 << endl;
}